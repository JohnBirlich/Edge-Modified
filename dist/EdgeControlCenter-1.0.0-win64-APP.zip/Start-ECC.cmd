@echo off
title Edge Control Center (fallback, browser mode)
where node >nul 2>nul
if %errorlevel%==0 (
  start "" http://127.0.0.1:3327/
  node "%~dp0app\server.js"
) else (
  echo Node.js not found. Install Node.js LTS from https://nodejs.org
  pause
)
