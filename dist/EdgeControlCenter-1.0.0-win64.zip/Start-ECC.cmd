@echo off
title Edge Control Center (fallback)
where node >nul 2>nul
if %errorlevel%==0 (
  node "%~dp0app\server.js"
) else (
  echo Node.js not found. Install Node.js LTS from https://nodejs.org
  pause
)
